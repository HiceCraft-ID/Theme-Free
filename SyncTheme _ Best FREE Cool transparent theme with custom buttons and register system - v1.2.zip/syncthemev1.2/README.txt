Installation steps:

1. Upload all files: app folder, resources foler, routes folder and tailwind config file into /var/www/pterodactyl

2. Run this commands: 

curl -sL https://deb.nodesource.com/setup_14.x | sudo -E bash -
apt install -y nodejs
curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | sudo apt-key add -
echo "deb https://dl.yarnpkg.com/debian/ stable main" | sudo tee /etc/apt/sources.list.d/yarn.list
sudo apt-get update
cd /var/www/pterodactyl
sudo apt-get install yarn -y
yarn install
yarn


3. After that run:

cd /var/www/pterodactyl && yarn build:production && chown -R www-data:www-data * && php artisan view:clear && php artisan cache:clear && php artisan migrate

4. Refresh the page


If you have any errors durring install contact me on discord

Dr.Ante#0727

Enjoy!